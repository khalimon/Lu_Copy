$(window).scroll(function () {

    var percent = ($(window).scrollTop() * 100) / ($(document).height() - $(window).height()); //$window.height = $(this).height

    $('.progressbar').css('width', Math.ceil(percent) + '%');

    console.log(percent);

    /*Menu changes*/
    if ($(this).scrollTop() > 565) {
        $('#main-nav').addClass('scroll');
    } else {
        $('#main-nav').removeClass('scroll');
    } //-?

});
